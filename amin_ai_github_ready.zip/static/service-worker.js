const CACHE_NAME = "amin-ai-cache-v1";

const APP_SHELL = [
    "/",
    "/static/manifest.json",
    "/static/icons/icon-192.png",
    "/static/icons/icon-512.png"
];


self.addEventListener("install", function (event) {

    event.waitUntil(
        caches.open(CACHE_NAME).then(function (cache) {
            return cache.addAll(APP_SHELL).catch(function () {
                // اگه بعضی فایل‌ها موقع نصب در دسترس نبودن، نذار کل نصب fail بشه
            });
        })
    );

    self.skipWaiting();
});


self.addEventListener("activate", function (event) {

    event.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(
                keys
                    .filter(function (key) { return key !== CACHE_NAME; })
                    .map(function (key) { return caches.delete(key); })
            );
        })
    );

    self.clients.claim();
});


self.addEventListener("fetch", function (event) {

    // فقط درخواست‌های GET رو کش می‌کنیم؛ درخواست‌های POST (مثل /chat،
    // /login و ...) همیشه باید مستقیم به سرور برن، هیچ‌وقت کش نمی‌شن
    if (event.request.method !== "GET") {
        return;
    }

    // network-first: همیشه اول تلاش می‌کنه از سرور بگیره (چون این یه اپ
    // زنده‌ست، نه یه سایت ایستا)، فقط اگه اینترنت/سرور در دسترس نبود
    // میره سراغ نسخه‌ی کش‌شده
    event.respondWith(
        fetch(event.request)
            .then(function (response) {

                const responseClone = response.clone();

                caches.open(CACHE_NAME).then(function (cache) {
                    cache.put(event.request, responseClone);
                });

                return response;
            })
            .catch(function () {
                return caches.match(event.request);
            })
    );
});
